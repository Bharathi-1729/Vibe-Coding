const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    table: { type: mongoose.Schema.Types.ObjectId, ref: 'Table', required: true },
    date: { type: String, required: true }, // stored as 'YYYY-MM-DD' for simple equality/range queries
    timeSlot: { type: String, required: true }, // e.g. '18:00-19:30'
    startMinutes: { type: Number, required: true }, // minutes since midnight, used for overlap math
    endMinutes: { type: Number, required: true },
    guests: { type: Number, required: true, min: 1 },
    status: {
      type: String,
      enum: ['confirmed', 'cancelled'],
      default: 'confirmed',
    },
  },
  { timestamps: true }
);

// Speeds up the core availability query (table + date + status)
reservationSchema.index({ table: 1, date: 1, status: 1 });

module.exports = mongoose.model('Reservation', reservationSchema);
