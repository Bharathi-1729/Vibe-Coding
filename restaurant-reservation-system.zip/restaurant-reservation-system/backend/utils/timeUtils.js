// Parses "HH:MM" into minutes since midnight
function toMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

// Parses a "HH:MM-HH:MM" time slot string into { startMinutes, endMinutes }
// Throws if the format is invalid or start >= end.
function parseTimeSlot(timeSlot) {
  const pattern = /^([01]\d|2[0-3]):([0-5]\d)-([01]\d|2[0-3]):([0-5]\d)$/;
  if (!pattern.test(timeSlot)) {
    throw new Error('timeSlot must be in the format "HH:MM-HH:MM", e.g. "18:00-19:30"');
  }
  const [startStr, endStr] = timeSlot.split('-');
  const startMinutes = toMinutes(startStr);
  const endMinutes = toMinutes(endStr);
  if (startMinutes >= endMinutes) {
    throw new Error('timeSlot start time must be before end time');
  }
  return { startMinutes, endMinutes };
}

// Two ranges overlap if one starts before the other ends, on both sides
function rangesOverlap(startA, endA, startB, endB) {
  return startA < endB && startB < endA;
}

// A simple 'YYYY-MM-DD' validator (kept intentionally strict/simple for the scope of this project)
function isValidDateString(dateStr) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return false;
  const d = new Date(dateStr + 'T00:00:00Z');
  return !Number.isNaN(d.getTime());
}

module.exports = { toMinutes, parseTimeSlot, rangesOverlap, isValidDateString };
