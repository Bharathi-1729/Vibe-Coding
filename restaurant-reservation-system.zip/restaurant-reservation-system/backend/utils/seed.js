// Seeds an admin user and a fixed set of tables.
// Run with: npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Table = require('../models/Table');

const seed = async () => {
  await connectDB();

  const adminEmail = 'admin@restaurant.com';
  const existingAdmin = await User.findOne({ email: adminEmail });
  if (!existingAdmin) {
    await User.create({
      name: 'Restaurant Admin',
      email: adminEmail,
      password: 'admin123', // change after first login in a real deployment
      role: 'admin',
    });
    console.log(`Admin created: ${adminEmail} / admin123`);
  } else {
    console.log('Admin already exists, skipping.');
  }

  const tableCount = await Table.countDocuments();
  if (tableCount === 0) {
    await Table.insertMany([
      { tableNumber: 1, capacity: 2 },
      { tableNumber: 2, capacity: 2 },
      { tableNumber: 3, capacity: 4 },
      { tableNumber: 4, capacity: 4 },
      { tableNumber: 5, capacity: 6 },
      { tableNumber: 6, capacity: 8 },
    ]);
    console.log('6 tables seeded.');
  } else {
    console.log('Tables already exist, skipping.');
  }

  await mongoose.disconnect();
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
