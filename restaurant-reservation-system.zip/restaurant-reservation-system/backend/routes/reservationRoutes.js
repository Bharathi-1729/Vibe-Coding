const express = require('express');
const {
  checkAvailability,
  createReservation,
  getMyReservations,
  cancelMyReservation,
  getAllReservations,
  adminUpdateReservation,
} = require('../controllers/reservationController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Customer routes
router.get('/availability', protect, checkAvailability);
router.post('/', protect, createReservation);
router.get('/my', protect, getMyReservations);
router.delete('/:id', protect, cancelMyReservation);

// Admin routes
router.get('/', protect, authorize('admin'), getAllReservations);
router.patch('/:id', protect, authorize('admin'), adminUpdateReservation);

module.exports = router;
