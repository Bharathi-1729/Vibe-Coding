const Reservation = require('../models/Reservation');
const Table = require('../models/Table');
const { asyncHandler } = require('../middleware/errorHandler');
const { parseTimeSlot, rangesOverlap, isValidDateString } = require('../utils/timeUtils');

// Finds all tables that are free for a given date/timeSlot and can seat `guests`.
// A table is free if no CONFIRMED reservation on that table/date overlaps the requested time range.
async function findAvailableTables({ date, startMinutes, endMinutes, guests }) {
  const candidateTables = await Table.find({
    isActive: true,
    capacity: { $gte: guests },
  }).sort('capacity'); // smallest-fit-first, to leave bigger tables free for bigger parties

  if (candidateTables.length === 0) return [];

  const existingReservations = await Reservation.find({
    date,
    status: 'confirmed',
    table: { $in: candidateTables.map((t) => t._id) },
  });

  const busyTableIds = new Set(
    existingReservations
      .filter((r) => rangesOverlap(startMinutes, endMinutes, r.startMinutes, r.endMinutes))
      .map((r) => r.table.toString())
  );

  return candidateTables.filter((t) => !busyTableIds.has(t._id.toString()));
}

// GET /api/reservations/availability?date=YYYY-MM-DD&timeSlot=HH:MM-HH:MM&guests=N
// Lets the frontend show which tables are actually bookable before submitting.
const checkAvailability = asyncHandler(async (req, res) => {
  const { date, timeSlot, guests } = req.query;

  if (!date || !timeSlot || !guests) {
    return res.status(400).json({ message: 'date, timeSlot and guests query params are required' });
  }
  if (!isValidDateString(date)) {
    return res.status(400).json({ message: 'date must be in the format YYYY-MM-DD' });
  }

  let startMinutes, endMinutes;
  try {
    ({ startMinutes, endMinutes } = parseTimeSlot(timeSlot));
  } catch (err) {
    return res.status(400).json({ message: err.message });
  }

  const guestCount = parseInt(guests, 10);
  if (!Number.isInteger(guestCount) || guestCount < 1) {
    return res.status(400).json({ message: 'guests must be a positive integer' });
  }

  const availableTables = await findAvailableTables({ date, startMinutes, endMinutes, guests: guestCount });
  res.status(200).json({ availableTables });
});

// POST /api/reservations  (customer)
// Body: { date, timeSlot, guests, tableId? }
// If tableId is provided, it is validated for capacity + conflicts.
// If omitted, the smallest suitable available table is auto-assigned.
const createReservation = asyncHandler(async (req, res) => {
  const { date, timeSlot, guests, tableId } = req.body;

  if (!date || !timeSlot || !guests) {
    return res.status(400).json({ message: 'date, timeSlot and guests are required' });
  }
  if (!isValidDateString(date)) {
    return res.status(400).json({ message: 'date must be in the format YYYY-MM-DD' });
  }

  // Disallow booking in the past (compared by date only, kept simple by design)
  const todayStr = new Date().toISOString().slice(0, 10);
  if (date < todayStr) {
    return res.status(400).json({ message: 'Cannot create a reservation for a past date' });
  }

  const guestCount = parseInt(guests, 10);
  if (!Number.isInteger(guestCount) || guestCount < 1) {
    return res.status(400).json({ message: 'guests must be a positive integer' });
  }

  let startMinutes, endMinutes;
  try {
    ({ startMinutes, endMinutes } = parseTimeSlot(timeSlot));
  } catch (err) {
    return res.status(400).json({ message: err.message });
  }

  let table;

  if (tableId) {
    table = await Table.findById(tableId);
    if (!table || !table.isActive) {
      return res.status(404).json({ message: 'Selected table does not exist or is inactive' });
    }
    if (table.capacity < guestCount) {
      return res.status(400).json({
        message: `Table ${table.tableNumber} seats ${table.capacity}, which is below the requested party size of ${guestCount}`,
      });
    }

    // Conflict check: pull all confirmed reservations for this table/date, then
    // check for time-range overlap in memory (overlap can't be expressed cleanly
    // as a single Mongo query with only start/end minute fields).
    const sameDayReservations = await Reservation.find({ table: table._id, date, status: 'confirmed' });
    const hasOverlap = sameDayReservations.some((r) => rangesOverlap(startMinutes, endMinutes, r.startMinutes, r.endMinutes));
    if (hasOverlap) {
      return res.status(409).json({
        message: `Table ${table.tableNumber} is already booked for an overlapping time slot on ${date}`,
      });
    }
  } else {
    // Auto-assign the smallest suitable, available table
    const available = await findAvailableTables({ date, startMinutes, endMinutes, guests: guestCount });
    if (available.length === 0) {
      return res.status(409).json({
        message: 'No tables are available for the requested date, time slot and party size',
      });
    }
    table = available[0];
  }

  const reservation = await Reservation.create({
    user: req.user._id,
    table: table._id,
    date,
    timeSlot,
    startMinutes,
    endMinutes,
    guests: guestCount,
    status: 'confirmed',
  });

  const populated = await reservation.populate('table');
  res.status(201).json({ reservation: populated });
});

// GET /api/reservations/my  (customer — own reservations only)
const getMyReservations = asyncHandler(async (req, res) => {
  const reservations = await Reservation.find({ user: req.user._id })
    .populate('table')
    .sort({ date: 1, startMinutes: 1 });
  res.status(200).json({ reservations });
});

// DELETE /api/reservations/:id  (customer — can only cancel their own)
const cancelMyReservation = asyncHandler(async (req, res) => {
  const reservation = await Reservation.findById(req.params.id);
  if (!reservation) return res.status(404).json({ message: 'Reservation not found' });

  if (reservation.user.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: 'You can only cancel your own reservations' });
  }
  if (reservation.status === 'cancelled') {
    return res.status(400).json({ message: 'Reservation is already cancelled' });
  }

  reservation.status = 'cancelled';
  await reservation.save();
  res.status(200).json({ message: 'Reservation cancelled', reservation });
});

// GET /api/reservations  (admin — all reservations, optional ?date=YYYY-MM-DD filter)
const getAllReservations = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.date) {
    if (!isValidDateString(req.query.date)) {
      return res.status(400).json({ message: 'date must be in the format YYYY-MM-DD' });
    }
    filter.date = req.query.date;
  }

  const reservations = await Reservation.find(filter)
    .populate('table')
    .populate('user', 'name email role')
    .sort({ date: 1, startMinutes: 1 });

  res.status(200).json({ reservations });
});

// PATCH /api/reservations/:id  (admin — update or cancel any reservation)
// Body may include: date, timeSlot, guests, tableId, status
const adminUpdateReservation = asyncHandler(async (req, res) => {
  const reservation = await Reservation.findById(req.params.id);
  if (!reservation) return res.status(404).json({ message: 'Reservation not found' });

  const { date, timeSlot, guests, tableId, status } = req.body;

  if (status) {
    if (!['confirmed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'status must be "confirmed" or "cancelled"' });
    }
  }

  const nextDate = date || reservation.date;
  const nextTimeSlot = timeSlot || reservation.timeSlot;
  const nextGuests = guests !== undefined ? parseInt(guests, 10) : reservation.guests;
  const nextTableId = tableId || reservation.table.toString();

  if (date && !isValidDateString(date)) {
    return res.status(400).json({ message: 'date must be in the format YYYY-MM-DD' });
  }

  let startMinutes, endMinutes;
  try {
    ({ startMinutes, endMinutes } = parseTimeSlot(nextTimeSlot));
  } catch (err) {
    return res.status(400).json({ message: err.message });
  }

  // Only re-validate capacity/conflicts if something relevant to availability changed
  const availabilityFieldsChanged =
    date || timeSlot || guests !== undefined || tableId;

  if (availabilityFieldsChanged) {
    const table = await Table.findById(nextTableId);
    if (!table || !table.isActive) {
      return res.status(404).json({ message: 'Target table does not exist or is inactive' });
    }
    if (table.capacity < nextGuests) {
      return res.status(400).json({
        message: `Table ${table.tableNumber} seats ${table.capacity}, which is below the requested party size of ${nextGuests}`,
      });
    }

    const sameDayReservations = await Reservation.find({
      table: table._id,
      date: nextDate,
      status: 'confirmed',
      _id: { $ne: reservation._id }, // exclude the reservation being edited
    });
    const hasOverlap = sameDayReservations.some((r) =>
      rangesOverlap(startMinutes, endMinutes, r.startMinutes, r.endMinutes)
    );
    if (hasOverlap) {
      return res.status(409).json({
        message: `Table ${table.tableNumber} is already booked for an overlapping time slot on ${nextDate}`,
      });
    }

    reservation.table = table._id;
    reservation.date = nextDate;
    reservation.timeSlot = nextTimeSlot;
    reservation.startMinutes = startMinutes;
    reservation.endMinutes = endMinutes;
    reservation.guests = nextGuests;
  }

  if (status) reservation.status = status;

  await reservation.save();
  const populated = await reservation.populate(['table', { path: 'user', select: 'name email role' }]);
  res.status(200).json({ reservation: populated });
});

module.exports = {
  checkAvailability,
  createReservation,
  getMyReservations,
  cancelMyReservation,
  getAllReservations,
  adminUpdateReservation,
};
