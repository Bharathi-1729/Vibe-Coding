const Table = require('../models/Table');
const { asyncHandler } = require('../middleware/errorHandler');

// GET /api/tables  (any authenticated user — customers need this to pick a table/see capacity)
const getTables = asyncHandler(async (req, res) => {
  const tables = await Table.find({ isActive: true }).sort('tableNumber');
  res.status(200).json({ tables });
});

// POST /api/tables  (admin only)
const createTable = asyncHandler(async (req, res) => {
  const { tableNumber, capacity } = req.body;

  if (tableNumber === undefined || capacity === undefined) {
    return res.status(400).json({ message: 'tableNumber and capacity are required' });
  }
  if (capacity < 1) {
    return res.status(400).json({ message: 'capacity must be at least 1' });
  }

  const table = await Table.create({ tableNumber, capacity });
  res.status(201).json({ table });
});

// PATCH /api/tables/:id  (admin only)
const updateTable = asyncHandler(async (req, res) => {
  const { capacity, isActive, tableNumber } = req.body;

  const table = await Table.findById(req.params.id);
  if (!table) return res.status(404).json({ message: 'Table not found' });

  if (capacity !== undefined) table.capacity = capacity;
  if (isActive !== undefined) table.isActive = isActive;
  if (tableNumber !== undefined) table.tableNumber = tableNumber;

  await table.save();
  res.status(200).json({ table });
});

// DELETE /api/tables/:id  (admin only) — soft delete to preserve reservation history integrity
const deleteTable = asyncHandler(async (req, res) => {
  const table = await Table.findById(req.params.id);
  if (!table) return res.status(404).json({ message: 'Table not found' });

  table.isActive = false;
  await table.save();
  res.status(200).json({ message: 'Table deactivated', table });
});

module.exports = { getTables, createTable, updateTable, deleteTable };
