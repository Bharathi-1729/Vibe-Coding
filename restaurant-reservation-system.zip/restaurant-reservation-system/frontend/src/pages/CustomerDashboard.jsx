import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function CustomerDashboard() {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionError, setActionError] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/reservations/my');
      setReservations(res.data.reservations);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load reservations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCancel = async (id) => {
    setActionError('');
    if (!window.confirm('Cancel this reservation?')) return;
    try {
      await api.delete(`/reservations/${id}`);
      load();
    } catch (err) {
      setActionError(err.response?.data?.message || 'Could not cancel reservation');
    }
  };

  if (loading) return <div className="page">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h2>My Reservations</h2>
        <Link to="/new" className="btn">+ New Reservation</Link>
      </div>
      {error && <div className="error-banner">{error}</div>}
      {actionError && <div className="error-banner">{actionError}</div>}

      {reservations.length === 0 ? (
        <p>You have no reservations yet.</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Date</th><th>Time</th><th>Table</th><th>Guests</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {reservations.map((r) => (
              <tr key={r._id} className={r.status === 'cancelled' ? 'row-cancelled' : ''}>
                <td>{r.date}</td>
                <td>{r.timeSlot}</td>
                <td>Table {r.table?.tableNumber} (seats {r.table?.capacity})</td>
                <td>{r.guests}</td>
                <td><span className={`status status-${r.status}`}>{r.status}</span></td>
                <td>
                  {r.status === 'confirmed' && (
                    <button className="btn-danger" onClick={() => handleCancel(r._id)}>Cancel</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
