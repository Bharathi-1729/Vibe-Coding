import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

const TIME_SLOTS = [
  '12:00-13:30', '13:30-15:00', '18:00-19:30', '19:30-21:00', '21:00-22:30',
];

export default function CreateReservation() {
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState(TIME_SLOTS[2]);
  const [guests, setGuests] = useState(2);
  const [availableTables, setAvailableTables] = useState(null);
  const [selectedTableId, setSelectedTableId] = useState('');
  const [checking, setChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const today = new Date().toISOString().slice(0, 10);

  const checkAvailability = async () => {
    setError('');
    setSuccess('');
    if (!date) {
      setError('Please choose a date first');
      return;
    }
    setChecking(true);
    try {
      const res = await api.get('/reservations/availability', {
        params: { date, timeSlot, guests },
      });
      setAvailableTables(res.data.availableTables);
      setSelectedTableId('');
    } catch (err) {
      setError(err.response?.data?.message || 'Could not check availability');
      setAvailableTables(null);
    } finally {
      setChecking(false);
    }
  };

  const handleBook = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSubmitting(true);
    try {
      await api.post('/reservations', {
        date,
        timeSlot,
        guests: Number(guests),
        tableId: selectedTableId || undefined,
      });
      setSuccess('Reservation confirmed!');
      setTimeout(() => navigate('/'), 1000);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create reservation');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="page">
      <h2>New Reservation</h2>
      {error && <div className="error-banner">{error}</div>}
      {success && <div className="success-banner">{success}</div>}

      <div className="card">
        <div className="form-row">
          <label>Date
            <input type="date" min={today} value={date} onChange={(e) => { setDate(e.target.value); setAvailableTables(null); }} required />
          </label>
          <label>Time slot
            <select value={timeSlot} onChange={(e) => { setTimeSlot(e.target.value); setAvailableTables(null); }}>
              {TIME_SLOTS.map((slot) => <option key={slot} value={slot}>{slot}</option>)}
            </select>
          </label>
          <label>Guests
            <input type="number" min={1} value={guests} onChange={(e) => { setGuests(e.target.value); setAvailableTables(null); }} required />
          </label>
        </div>
        <button onClick={checkAvailability} disabled={checking}>
          {checking ? 'Checking...' : 'Check Availability'}
        </button>
      </div>

      {availableTables !== null && (
        <div className="card">
          <h3>Available Tables</h3>
          {availableTables.length === 0 ? (
            <p>No tables available for this date, time and party size. Try a different slot.</p>
          ) : (
            <form onSubmit={handleBook}>
              <div className="table-options">
                {availableTables.map((t) => (
                  <label key={t._id} className={`table-option ${selectedTableId === t._id ? 'selected' : ''}`}>
                    <input
                      type="radio"
                      name="table"
                      value={t._id}
                      checked={selectedTableId === t._id}
                      onChange={() => setSelectedTableId(t._id)}
                    />
                    Table {t.tableNumber} (seats {t.capacity})
                  </label>
                ))}
              </div>
              <button type="submit" disabled={submitting || !selectedTableId}>
                {submitting ? 'Booking...' : 'Confirm Reservation'}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
