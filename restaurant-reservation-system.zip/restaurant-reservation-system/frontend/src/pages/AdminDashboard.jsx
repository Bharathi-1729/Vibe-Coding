import { useEffect, useState } from 'react';
import api from '../api/axios';

export default function AdminDashboard() {
  const [reservations, setReservations] = useState([]);
  const [dateFilter, setDateFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ date: '', timeSlot: '', guests: '' });

  const load = async (date) => {
    setLoading(true);
    setError('');
    try {
      const res = await api.get('/reservations', { params: date ? { date } : {} });
      setReservations(res.data.reservations);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load reservations');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const applyFilter = (e) => {
    e.preventDefault();
    load(dateFilter || undefined);
  };

  const clearFilter = () => {
    setDateFilter('');
    load();
  };

  const handleCancel = async (id) => {
    if (!window.confirm('Cancel this reservation?')) return;
    try {
      await api.patch(`/reservations/${id}`, { status: 'cancelled' });
      load(dateFilter || undefined);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not cancel reservation');
    }
  };

  const startEdit = (r) => {
    setEditingId(r._id);
    setEditForm({ date: r.date, timeSlot: r.timeSlot, guests: r.guests });
  };

  const saveEdit = async (id) => {
    try {
      await api.patch(`/reservations/${id}`, {
        date: editForm.date,
        timeSlot: editForm.timeSlot,
        guests: Number(editForm.guests),
      });
      setEditingId(null);
      load(dateFilter || undefined);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not update reservation');
    }
  };

  if (loading) return <div className="page">Loading...</div>;

  return (
    <div className="page">
      <h2>All Reservations (Admin)</h2>
      {error && <div className="error-banner">{error}</div>}

      <form className="filter-row" onSubmit={applyFilter}>
        <label>Filter by date
          <input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} />
        </label>
        <button type="submit">Filter</button>
        <button type="button" className="btn-link" onClick={clearFilter}>Clear</button>
      </form>

      {reservations.length === 0 ? (
        <p>No reservations found.</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Customer</th><th>Date</th><th>Time</th><th>Table</th><th>Guests</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {reservations.map((r) => (
              <tr key={r._id} className={r.status === 'cancelled' ? 'row-cancelled' : ''}>
                <td>{r.user?.name}<br /><small>{r.user?.email}</small></td>
                {editingId === r._id ? (
                  <>
                    <td><input type="date" value={editForm.date} onChange={(e) => setEditForm({ ...editForm, date: e.target.value })} /></td>
                    <td><input value={editForm.timeSlot} onChange={(e) => setEditForm({ ...editForm, timeSlot: e.target.value })} placeholder="HH:MM-HH:MM" /></td>
                    <td>Table {r.table?.tableNumber}</td>
                    <td><input type="number" min={1} value={editForm.guests} onChange={(e) => setEditForm({ ...editForm, guests: e.target.value })} /></td>
                    <td><span className={`status status-${r.status}`}>{r.status}</span></td>
                    <td>
                      <button className="btn" onClick={() => saveEdit(r._id)}>Save</button>
                      <button className="btn-link" onClick={() => setEditingId(null)}>Cancel</button>
                    </td>
                  </>
                ) : (
                  <>
                    <td>{r.date}</td>
                    <td>{r.timeSlot}</td>
                    <td>Table {r.table?.tableNumber} (seats {r.table?.capacity})</td>
                    <td>{r.guests}</td>
                    <td><span className={`status status-${r.status}`}>{r.status}</span></td>
                    <td>
                      {r.status === 'confirmed' && (
                        <>
                          <button className="btn-link" onClick={() => startEdit(r)}>Edit</button>
                          <button className="btn-danger" onClick={() => handleCancel(r._id)}>Cancel</button>
                        </>
                      )}
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
