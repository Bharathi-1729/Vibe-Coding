import { useEffect, useState } from 'react';
import api from '../api/axios';

export default function AdminTables() {
  const [tables, setTables] = useState([]);
  const [tableNumber, setTableNumber] = useState('');
  const [capacity, setCapacity] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get('/tables');
      setTables(res.data.tables);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load tables');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/tables', { tableNumber: Number(tableNumber), capacity: Number(capacity) });
      setTableNumber('');
      setCapacity('');
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create table');
    }
  };

  const handleDeactivate = async (id) => {
    if (!window.confirm('Deactivate this table? It will no longer be bookable.')) return;
    try {
      await api.delete(`/tables/${id}`);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not deactivate table');
    }
  };

  const handleCapacityChange = async (id, newCapacity) => {
    try {
      await api.patch(`/tables/${id}`, { capacity: Number(newCapacity) });
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not update table');
    }
  };

  if (loading) return <div className="page">Loading...</div>;

  return (
    <div className="page">
      <h2>Manage Tables</h2>
      {error && <div className="error-banner">{error}</div>}

      <div className="card">
        <h3>Add Table</h3>
        <form className="form-row" onSubmit={handleCreate}>
          <label>Table Number
            <input type="number" min={1} value={tableNumber} onChange={(e) => setTableNumber(e.target.value)} required />
          </label>
          <label>Capacity
            <input type="number" min={1} value={capacity} onChange={(e) => setCapacity(e.target.value)} required />
          </label>
          <button type="submit">Add Table</button>
        </form>
      </div>

      <table className="table">
        <thead><tr><th>Table #</th><th>Capacity</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {tables.map((t) => (
            <tr key={t._id}>
              <td>{t.tableNumber}</td>
              <td>
                <input
                  type="number"
                  min={1}
                  defaultValue={t.capacity}
                  onBlur={(e) => e.target.value != t.capacity && handleCapacityChange(t._id, e.target.value)}
                  style={{ width: '60px' }}
                />
              </td>
              <td>{t.isActive ? 'Active' : 'Inactive'}</td>
              <td><button className="btn-danger" onClick={() => handleDeactivate(t._id)}>Deactivate</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
