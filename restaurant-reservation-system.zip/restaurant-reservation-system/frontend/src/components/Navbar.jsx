import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/">🍽️ Restaurant Reservations</Link>
        {user?.role === 'admin' && <span className="admin-badge">ADMIN</span>}
      </div>
      <div className="navbar-links">
        {user ? (
          <>
            {user.role === 'customer' && (
              <>
                <Link to="/">My Reservations</Link>
                <Link to="/new">New Reservation</Link>
              </>
            )}
            {user.role === 'admin' && (
              <>
                <Link to="/">All Reservations</Link>
                <Link to="/admin/tables">Manage Tables</Link>
              </>
            )}
            <span className="navbar-user">Hi, {user.name}</span>
            <button onClick={handleLogout} className="btn-link">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
