import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import CustomerDashboard from './pages/CustomerDashboard';
import CreateReservation from './pages/CreateReservation';
import AdminDashboard from './pages/AdminDashboard';
import AdminTables from './pages/AdminTables';

function HomeRoute() {
  const { user } = useAuth();
  if (user?.role === 'admin') return <AdminDashboard />;
  return <CustomerDashboard />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <div className="container">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/" element={<ProtectedRoute><HomeRoute /></ProtectedRoute>} />
            <Route path="/new" element={<ProtectedRoute role="customer"><CreateReservation /></ProtectedRoute>} />
            <Route path="/admin/tables" element={<ProtectedRoute role="admin"><AdminTables /></ProtectedRoute>} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
